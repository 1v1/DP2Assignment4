package it.polito.dp2.FDS.sol4.server;

public class DataManagerException extends Exception{
	
	public DataManagerException(String msg)
	{
		super(msg);
	}
	
	public DataManagerException()
	{
		super();
	}

}
