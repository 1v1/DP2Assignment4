@javax.xml.bind.annotation.XmlSchema(namespace = "http://pad.polito.it/FDSInfo")
package it.polito.dp2.FDS.sol4.server.jaxws;
