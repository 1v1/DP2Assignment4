@javax.xml.bind.annotation.XmlSchema(namespace = "http://pad.polito.it/FDS")
package it.polito.dp2.FDS.sol4.server.jaxws;
